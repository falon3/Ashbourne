sudo su - postgres

createuser -d -E -i -l -P -r -s admin_lsb 123


sudo apt-get install python-pip python-dev build-essential 
sudo pip install --upgrade pip 
sudo pip install --upgrade virtualenv 

keytool -genkey -keyalg RSA -alias my_home -keystore herong.jks -validity 360 -keysize 2048



keytool.exe -exportcert -alias my_home -file my_home.crt -keystore herong.jks -storepass HerongJKS



keytool.exe -importcert -alias herong_home -file my_home.crt -keystore public.jks -storepass PublicJKS


java -cp . -Djavax.net.ssl.trustStore=public.jks SslSocketClient




keytool -import -alias herong_home -file my_home.crt -keystore public.jks -storetype BKS -storepass ssltestcert -providerClass org.bouncycastle.jce.provider.BouncyCastleProvider -providerpath /home/alex/Desktop/IoT_App/CampusLBS/app/libs/











keytool -genkey -dname "cn=ssltest, ou=test, o=example, c=US" -alias ssltest -keypass ssltest -keystore /home/alex/ssltest.keystore -storepass ssltest -validity 180


keytool -export -alias ssltest -keystore /home/alex/ssltest.keystore -file /home/alex/ssltest.cer -storepass ssltest -keypass ssltest



keytool -import -alias ssltestcert -file /home/alex/ssltest.cer -keypass ssltestcert -keystore /home/alex/Desktop/IoT_App/CampusLBS/app/src/main/res/raw/ssltestcert -storetype BKS -storepass ssltestcert -providerClass org.bouncycastle.jce.provider.BouncyCastleProvider -providerpath /home/alex/Desktop/IoT_App/CampusLBS/app/libs/bcprov-jdk15on-154.jar


keytool -import -alias ssltestcert2 -file /home/alex/my_home.crt -keypass Alexandr8989 -keystore /home/alex/Desktop/IoT_App/CampusLBS/app/src/main/res/raw/ssltestcert2 -storetype BKS -storepass Alexandr89 -providerClass org.bouncycastle.jce.provider.BouncyCastleProvider -providerpath /home/alex/Desktop/IoT_App/CampusLBS/app/libs/bcprov-jdk15on-154.jar


java -cp . -Djavax.net.ssl.trustStore=ssltest.cer SslSocketClient

